/*
 * usb_const.h
 *
 *  Created on: May 8, 2025
 *      Author: ouyangzonghua
 */

#ifndef INC_USB_CONSTANT_H_
#define INC_USB_CONSTANT_H_

//Constants below are listed in Table 8-3 on page 204 of Universal Serial Bus Specification Revision 2.0
#define CSM_USB_EP_TYPE_CONTROL			0x00
#define CSM_USB_EP_TYPE_ISOCHRONOUS		0x01
#define CSM_USB_EP_TYPE_BULK				0x02
#define CSM_USB_EP_TYPE_INTERRUPT		0x03

//Constants below are listed in Table 9-4 on page 251 of Universal Serial Bus Specification Revision 2.0
#define CSM_USB_REQUEST_GET_STATUS			0
#define CSM_USB_REQUEST_CLEAR_FEATURE		1
#define CSM_USB_REQUEST_SET_FEATURE			3
#define CSM_USB_REQUEST_SET_ADDRESS			5
#define CSM_USB_REQUEST_GET_DESCRIPTOR		6
#define CSM_USB_REQUEST_SET_DESCRIPTOR		7
#define CSM_USB_REQUEST_GET_CONFIGURATION 	8
#define CSM_USB_REQUEST_SET_CONFIGURATION 	9
#define CSM_USB_REQUEST_GET_INTERFACE		10
#define CSM_USB_REQUEST_SET_INTERFACE		11
#define CSM_USB_REQUEST_SYNCH_FRAME			12

//Constants below are listed in Table 9-5 on page 251 of Universal Serial Bus Specification Revision 2.0
#define CSM_USB_DESCRIPTOR_DEVICE						1
#define CSM_USB_DESCRIPTOR_CONFIGURATION				2
#define CSM_USB_DESCRIPTOR_STRING						3
#define CSM_USB_DESCRIPTOR_INTERFACE					4
#define CSM_USB_DESCRIPTOR_ENDPOINT						5
#define CSM_USB_DESCRIPTOR_DEVICE_QUALIFIER				6
#define CSM_USB_DESCRIPTOR_OTHER_SPEED_CONFIGURATION	7
#define CSM_USB_DESCRIPTOR_INTERFACE_POWER				8

#endif /* INC_USB_CONSTANT_H_ */
