/*
 * usb_descriptor.h
 *
 *  Created on: May 8, 2025
 *      Author: ouyangzonghua
 */

#ifndef INC_USB_DESCRIPTOR_H_
#define INC_USB_DESCRIPTOR_H_

#include <string.h>
#include <usb_setting.h>


uint8_t USB_StringDescriptor[12][256] = {
		//USB String Descriptors are encoded using UTF-16LE
		{0x04, 0x14},
		{0x27, 0x6b, 0x27, 0x59, 0x6c, 0x4f}, //iManufacturer
		{0x53, 0x00, 0x54, 0x00, 0x4d, 0x00, 0x33, 0x00, 0x32, 0x00, 0x20, 0x00, 0x55, 0x00, 0x53, 0x00, 0x42, 0x00, 0x20, 0x00, 0x4b, 0x6d, 0xd5, 0x8b, 0x00, 0x5f, 0xd1, 0x53, 0x7f, 0x67}, //iProduct
		{0x55, 0x00, 0x53, 0x00, 0x42, 0x00, 0x32, 0x00, 0x33, 0x00, 0x33, 0x00, 0x33, 0x00, 0x33, 0x00, 0x33, 0x00, 0x33, 0x00, 0x33, 0x00, 0x33, 0x00, 0x33, 0x00,}, //iSerialNumber
		{0xd8, 0x9e, 0xa4, 0x8b, 0x20, 0x00, 0x43, 0x00, 0x6f, 0x00, 0x6e, 0x00, 0x66, 0x00, 0x69, 0x00, 0x67, 0x00, 0x75, 0x00, 0x72, 0x00, 0x61, 0x00, 0x74, 0x00, 0x69, 0x00, 0x6f, 0x00, 0x6e, 0x00}, //iConfiguration
		{0xd8, 0x9e, 0xa4, 0x8b, 0x20, 0x00, 0x49, 0x00, 0x6e, 0x00, 0x74, 0x00, 0x65, 0x00, 0x72, 0x00, 0x66, 0x00, 0x61, 0x00, 0x63, 0x00, 0x65, 0x00}, //iInterface

};

//Standard Device Descriptor is defined in Table 9-8 on page 262 of Universal Serial Bus Specification Revision 2.0
uint8_t USB_DeviceDescriptor[18] = {
		18,		//bLength, Size of this descriptor in bytes
		CSM_USB_DESCRIPTOR_DEVICE, //bDescriptorType, DEVICE Descriptor Type
		0x00, //bcdUSB, USB Specification Release Number in Binary-Coded Decimal (i.e., 2.10 is 210H). This field identifies the release of the USB Specification with which the device and its descriptors are compliant.
		0x02,
		0x00, //bDeviceClass, Class code (assigned by the USB-IF)
		0x00, //bDeviceSubClass, Subclass code (assigned by the USB-IF)
		0x00, //bDeviceProtocol, Protocol code (assigned by the USB-IF)
		64, //bMaxPacketSize, Maximum packet size for endpoint zero (only 8, 16, 32, or 64 are valid)
		0x48, //idVendor, Vendor ID (assigned by the USB-IF)
		0x06,
		0xEE, //idProduct, Product ID (assigned by the manufacturer)
		0xEE,
		0xEE, //bcdDevice, Device release number in binary-coded decimal
		0xEE,
		1, //iManufacturer, Index of string descriptor describing manufacturer
		2, //iProduct, Index of string descriptor describing product
		3, //iSerialNumber, Index of string descriptor describing the device’s serial number
		1, //bNumConfigurations, Number of possible configurations
};

//Standard Configuration Descriptor is defined in Table 9-10 on page 265 of Universal Serial Bus Specification Revision 2.0
uint8_t USB_ConfigurationDescriptor[9] = {
		9, //bLength, Size of this descriptor in bytes
		CSM_USB_DESCRIPTOR_CONFIGURATION, //bDescriptorType, CONFIGURATION Descriptor Type
		0, //wTotalLength, Total length of data returned for this configuration.
		0,
		1, //bNumInterfaces, Number of interfaces supported by this configuration
		1, //bConfigurationValue, Value to use as an argument to the SetConfiguration() request to select this configuration
		4, //iConfiguration, Index of string descriptor describing this configuration
		0x80, //bmAttributes, Configuration characteristics
		200, //bMaxPower, Maximum power consumption of the USB device. Expressed in 2 mA units
};

//Standard Interface Descriptor is defined in Table 9-12 on page 268 of Universal Serial Bus Specification Revision 2.0
uint8_t USB_InterfaceDescriptor[9] = {
		9, //bLength, Size of this descriptor in bytes
		CSM_USB_DESCRIPTOR_INTERFACE, //bDescriptorType, INTERFACE Descriptor Type
		0, //bInterfaceNumber, Number of this interface.
		0, //bAlternateSetting, Value used to select this alternate setting for the interface identified in the prior field
		CSM_USB_EP_COUNT, //Number of endpoints used by this interface (excluding endpoint zero).
		0xFF, //bInterfaceClass, Class code (assigned by the USB-IF).
		0xFF, //bInterfaceSubClass, Subclass code (assigned by the USB-IF)
		0xFF, //bInterfaceProtocol, Protocol code (assigned by the USB)
		5,
};

//Standard Endpoint Descriptor is defined in Table 9-13 on page 269 of Universal Serial Bus Specification Revision 2.0
uint8_t USB_EndpointDescriptor[CSM_USB_EP_COUNT][7] = {
		//Endpoint 1, OUT, BULK
		{
				7, //bLength, Size of this descriptor in bytes
				CSM_USB_DESCRIPTOR_ENDPOINT, //ENDPOINT Descriptor Type
				0x01, //bEndpointAddress, EP1, OUT
				0x02, //bmAttributes, Bulk endpoint
				0x00, //wMaxPacketSize, For all endpoints, bits 10..0 specify the maximum packet size (in bytes). 512
				0x02,
				0xFF, //bInterval, Interval for polling endpoint for data transfers. 255 ms
		},
		//Endpoint 1, IN, BULK
		{
				7, //bLength, Size of this descriptor in bytes
				CSM_USB_DESCRIPTOR_ENDPOINT, //ENDPOINT Descriptor Type
				0x81, //bEndpointAddress, EP1, IN
				0x02, //bmAttributes, Bulk endpoint
				0x00, //wMaxPacketSize, For all endpoints, bits 10..0 specify the maximum packet size (in bytes). 512
				0x02,
				0xFF, //bInterval, Interval for polling endpoint for data transfers. 255 ms
		},
};
#endif /* INC_USB_DESCRIPTOR_H_ */
