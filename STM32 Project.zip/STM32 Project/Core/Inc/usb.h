/*
 * usb.h
 *
 *  Created on: May 7, 2025
 *      Author: ouyangzonghua
 */

#ifndef INC_USB_H_
#define INC_USB_H_

#define min(a, b) ((a < b) ? a : b)

#define CSM_USB_STATE_NOT_CONFIGURED 0x00
#define CSM_USB_STATE_CONFIGURED 0xCF

typedef struct {
	//Request formats below is defined in Table 9-2 on page 248 of Universal Serial Bus Specification Revision 2.0
	uint8_t bmRequestType;
	uint8_t bRequest;
	uint16_t wValue;
	uint16_t wIndex;
	uint16_t wLength;
} CSM_USB_RequestTypeDef;

typedef struct {
	PCD_HandleTypeDef* pData;
	uint32_t USBReceiveInterrupt;
	uint32_t USBTransmitInterrupt;
	uint32_t USBState;
	uint8_t USBSetupTxBuffer[64];
	uint8_t USBReceiveBuffer[64];
} USB_IvarsTypeDef;

extern volatile USB_IvarsTypeDef CSM_USB_Ivars;

void CSM_USB_Start();

#endif /* INC_USB_H_ */
