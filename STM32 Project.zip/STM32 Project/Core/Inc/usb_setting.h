/*
 * usb_setting.h
 *
 *  Created on: May 10, 2025
 *      Author: ouyangzonghua
 */

#ifndef INC_USB_SETTING_H_
#define INC_USB_SETTING_H_

#define CSM_USB_EP_COUNT	2

#endif /* INC_USB_SETTING_H_ */
