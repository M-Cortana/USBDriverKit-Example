/*
 * debug.h
 *
 *  Created on: May 7, 2025
 *      Author: ouyangzonghua
 */

#ifndef INC_DEBUG_H_
#define INC_DEBUG_H_
#include "main.h"
#include <string.h>
#include <stdio.h>

extern char __debug_temp_str__[2048];

#define CSM_DEBUG_Log(fmt, ...) {sprintf(__debug_temp_str__, fmt"\n\r", ##__VA_ARGS__); CSM_DEBUG_Print(__debug_temp_str__);}
#define CSM_DEBUG_HALStatusToStr(sta) (sta == HAL_OK ? "HAL_OK" : sta == HAL_ERROR ? "HAL_ERROR" : sta == HAL_BUSY ? "HAL_BUSY" : sta == HAL_TIMEOUT ? "HAL_TIMEOUT" : "HAL_UNDEFINED")

void CSM_DEBUG_Print(char *str);

#endif /* INC_DEBUG_H_ */
