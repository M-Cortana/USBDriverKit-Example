/*
 * usb.c
 *
 *  Created on: May 7, 2025
 *      Author: ouyangzonghua
 */

#include "main.h"
#include "debug.h"
#include "usb_constant.h"
#include "usb_descriptor.h"
#include "usb.h"
#include "usb_setting.h"
#include <wchar.h>

#define Log(fmt, ...) CSM_DEBUG_Log("usb.c: "fmt, ##__VA_ARGS__)
#define Ret(ret) CSM_DEBUG_HALStatusToStr(ret)

#define CSM_USB_bReqToStr(bReq) (bReq == 0 ? "GET_STATUS " : bReq == 1 ? "CLEAR_FEATURE" : bReq == 3 ? "SET_FEATURE" : bReq == 5 ? "SET_ADDRESS" : bReq == 6 ? "GET_DESCRIPTOR" : bReq == 7 ? "SET_DESCRIPTOR" : bReq == 8 ? "GET_CONFIGURATION" : bReq == 9 ? "SET_CONFIGURATION" : bReq == 10 ? "GET_INTERFACE" : bReq == 11 ? "SET_INTERFACE" : bReq == 12 ? "SYNCH_FRAME" : "REQUEST_UNDEFINED")

#define CSM_USB_PCD_Handle hpcd_USB_OTG_FS

void LogReq(CSM_USB_RequestTypeDef req) {
	Log("{bmRequestType = 0x%X; bRequest = %u: %s; wValue = 0x%X; wIndex = %u; wLength = %u;}", req.bmRequestType, req.bRequest, CSM_USB_bReqToStr(req.bRequest), req.wValue, req.wIndex, req.wLength);
}


volatile USB_IvarsTypeDef CSM_USB_Ivars;
volatile USB_IvarsTypeDef *ivars;

uint16_t CSM_USB_Strlen16(uint8_t *str) {
	uint16_t maxlen = 256;
	for (uint8_t *i = str; i < str + maxlen; i+=2) {
		if (*i == 0 && *(i+1) == 0) {
			return i - str;
		}
	}
	return 256;
}

uint16_t SWAPBYTE(uint8_t *addr) {
	uint16_t _SwapVal = 0;
	uint16_t _Byte1 = 0;
	uint16_t _Byte2 = 0;
	uint8_t *_pbuff = addr;
	_Byte1 = *(uint8_t *)_pbuff;
	_pbuff++;
	_Byte2 = *(uint8_t *)_pbuff;
	_SwapVal = (_Byte2 << 8) | _Byte1;
	return _SwapVal;
}


CSM_USB_RequestTypeDef CSM_USB_ParseRequest(uint8_t *req) {
	CSM_USB_RequestTypeDef res;
	res.bmRequestType = *req;
	req++;
	res.bRequest = *(req);
	req++;
	res.wValue = SWAPBYTE(req);
	req++;
	req++;
	res.wIndex = SWAPBYTE(req);
	req++;
	req++;
	res.wLength = SWAPBYTE(req);
	return res;
}

void CSM_USB_Start() {
	HAL_StatusTypeDef ret = HAL_OK;
	Log("CSM_USB_Start()");
	ivars = &CSM_USB_Ivars;
	CSM_USB_PCD_Handle.pData = ivars;
	ivars->pData = &CSM_USB_PCD_Handle;

	HAL_PCDEx_SetTxFiFo(ivars->pData, 0, 64);
	HAL_PCDEx_SetTxFiFo(ivars->pData, 1, 128);
	HAL_PCDEx_SetRxFiFo(ivars->pData, 128);
	ret = HAL_PCD_Start(ivars->pData);	//Enable PCD transmission and reception:
	Log("HAL_PCD_Start() = %s", Ret(ret));
}

void CSM_USB_DevReqHandle(PCD_HandleTypeDef *hpcd, CSM_USB_RequestTypeDef req) {
	uint8_t *TxBuf = ivars->USBSetupTxBuffer;
	switch (req.bRequest) {
		case CSM_USB_REQUEST_SET_ADDRESS:
			HAL_PCD_SetAddress(hpcd, req.wValue);
			HAL_PCD_EP_Transmit(hpcd, 0x00, NULL, 0);
			break;
		case CSM_USB_REQUEST_GET_DESCRIPTOR:
			switch((req.wValue & 0xFF00) >> 8) {
				case CSM_USB_DESCRIPTOR_DEVICE:
					HAL_PCD_EP_Transmit(hpcd, 0x00, USB_DeviceDescriptor, min(*USB_DeviceDescriptor, req.wLength));
					HAL_PCD_EP_Receive(hpcd, 0x00, NULL, 0);
					break;
				case CSM_USB_DESCRIPTOR_STRING:
					TxBuf[0] = CSM_USB_Strlen16(USB_StringDescriptor[req.wValue & 0xFF]) + 2;
					TxBuf[1] = CSM_USB_DESCRIPTOR_STRING;
					memcpy(TxBuf + 2, USB_StringDescriptor[req.wValue & 0xFF], *TxBuf - 2);
					HAL_PCD_EP_Transmit(hpcd, 0x00, TxBuf, min(*TxBuf, req.wLength));
					HAL_PCD_EP_Receive(hpcd, 0x00, NULL, 0);
					break;
				case CSM_USB_DESCRIPTOR_CONFIGURATION:
					memcpy(TxBuf, USB_ConfigurationDescriptor, *USB_ConfigurationDescriptor);
					memcpy(TxBuf + *USB_ConfigurationDescriptor, USB_InterfaceDescriptor, *USB_InterfaceDescriptor);
					memcpy(TxBuf + *USB_ConfigurationDescriptor + *USB_InterfaceDescriptor, USB_EndpointDescriptor, **USB_EndpointDescriptor * CSM_USB_EP_COUNT);
					TxBuf[2] = *TxBuf + *USB_InterfaceDescriptor + **USB_EndpointDescriptor * CSM_USB_EP_COUNT;
					HAL_PCD_EP_Transmit(hpcd, 0x00, TxBuf, min(TxBuf[2], req.wLength));
					HAL_PCD_EP_Receive(hpcd, 0x00, NULL, 0);
					break;
				default:
					HAL_PCD_EP_Transmit(hpcd, 0x00, NULL, 0);
					HAL_PCD_EP_Receive(hpcd, 0x00, NULL, 0);
			}
			break;
			case CSM_USB_REQUEST_SET_CONFIGURATION:
				ivars->USBState = CSM_USB_STATE_CONFIGURED;
				HAL_PCD_EP_Transmit(hpcd, 0x00, NULL, 0);
				break;

	}
	Log("CSM_USB_DevReqHandle() Finished");
}

void CSM_USB_IntReqHandle(CSM_USB_RequestTypeDef req) {
	Log("CSM_USB_IntReqHandle()");
}

void CSM_USB_EpReqHandle(CSM_USB_RequestTypeDef req) {
	Log("CSM_USB_EpReqHandle()");
}

void HAL_PCD_SetupStageCallback(PCD_HandleTypeDef *hpcd) {
	Log("HAL_PCD_SetupStageCallback()");
	CSM_USB_RequestTypeDef req = CSM_USB_ParseRequest((uint8_t*) hpcd->Setup);
	LogReq(req);
	switch (req.bmRequestType & 0x1F) {
		case 0:
			CSM_USB_DevReqHandle(hpcd, req);
			break;
		case 1:
			CSM_USB_IntReqHandle(req);
			break;
		case 2:
			CSM_USB_EpReqHandle(req);
			break;
		default:
			//HAL_PCD_EP_SetStall(hpcd, req.bmRequestType & 0x80);
			Log("No Request Matched; HAL_PCD_EP_SetStall()");
			break;
	}
}

void HAL_PCD_DataOutStageCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum) {
	Log("HAL_PCD_DataOutStageCallback(epnum = %u)", epnum);
	ivars->USBReceiveInterrupt = (hpcd->OUT_ep[epnum].xfer_count) | 0x80000000;
}

void HAL_PCD_DataInStageCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum) {
	Log("HAL_PCD_DataInStageCallback(epnum = %u)", epnum);
	//HAL_PCD_EP_Transmit(hpcd, 0x00, NULL, 0);
}
void HAL_PCD_ConnectCallback(PCD_HandleTypeDef *hpcd) {
	Log("HAL_PCD_ConnectCallback");
}

void HAL_PCD_ResetCallback(PCD_HandleTypeDef *hpcd) {
	Log("HAL_PCD_ResetCallback()");
	ivars->USBState = CSM_USB_STATE_NOT_CONFIGURED;
	HAL_PCD_EP_Open(hpcd, 0x00, 64, CSM_USB_EP_TYPE_CONTROL);
	//Log("HAL_PCD_EP_Open(epnum = 0x00) = %s", Ret(ret));
	HAL_PCD_EP_Open(hpcd, 0x80, 64, CSM_USB_EP_TYPE_CONTROL);
	//Log("HAL_PCD_EP_Open(epnum = 0x80) = %s", Ret(ret));
	HAL_PCD_EP_Open(hpcd, 0x01, 64, CSM_USB_EP_TYPE_BULK);
	//Log("HAL_PCD_EP_Open(epnum = 0x01) = %s", Ret(ret));
	HAL_PCD_EP_Open(hpcd, 0x81, 64, CSM_USB_EP_TYPE_BULK);
}
