/*
 * debug.c
 *
 *  Created on: May 7, 2025
 *      Author: ouyangzonghua
 */

#include "debug.h"

char __debug_temp_str__[2048];

void CSM_DEBUG_Print(char *str) {
	HAL_UART_Transmit(&huart1, (uint8_t*) str, strlen(str), 1000);
}
